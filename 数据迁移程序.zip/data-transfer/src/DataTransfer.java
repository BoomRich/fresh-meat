import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;

import java.sql.*;

/**
 * Created by chenrz925 on 2017/7/10.
 * 上午1:14 Project: data-transfer
 *
 * @author chenrz925
 */
public class DataTransfer {
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.jdbc.Driver");
        Connection sqliteCon = DriverManager.getConnection("jdbc:sqlite:/Users/chenrz925/Documents/Workspace/bookish-broccoli/Python/jdfresh.sqlite");
        Connection mysqlCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/?useSSL=false", "root", "Chenrunze925");
        Statement sqliteSt = sqliteCon.createStatement();
        ResultSet sqliteRS;
        Statement mysqlSt = mysqlCon.createStatement();
        sqliteRS = sqliteSt.executeQuery("SELECT DISTINCT main.fresh.class FROM main.fresh ORDER BY main.fresh.class");
        int i = 1;
        do {
            try {
                if (!sqliteRS.getString("class").equals("") && !mysqlSt.execute("INSERT INTO freshmeat.Category VALUES (\"" + i + "\",\"" + sqliteRS.getString("class") + "\")"))
                    i++;
            } catch (MySQLIntegrityConstraintViolationException e) {
                System.out.print(".");
            }
        } while (sqliteRS.next());
        System.out.println();
        sqliteRS = sqliteSt.executeQuery("SELECT * FROM main.fresh");
        ResultSet mysqlRS = null;
        do {
            String sql = "INSERT INTO freshmeat.Product VALUES (product_id, product_name, product_price, product_brand, product_location, shipping_location, preview_image, detail_image, (SELECT category_id FROM freshmeat.Category WHERE category_name=CATNM))"
                    .replaceAll("product_id", "\"" + sqliteRS.getInt("id") + "\"")
                    .replaceAll("product_name", "\"" + sqliteRS.getString("sku_name") + "\"")
                    .replaceAll("product_price", "\"" + sqliteRS.getBigDecimal("price") + "\"")
                    .replaceAll("product_brand", "\"" + sqliteRS.getString("brand") + "\"")
                    .replaceAll("product_location", "\"" + sqliteRS.getString("prolocation") + "\"")
                    .replaceAll("shipping_location", "\"" + sqliteRS.getString("shiplocation") + "\"")
                    .replaceAll("preview_image", "\"" + sqliteRS.getInt("prepicnum") + "\"")
                    .replaceAll("detail_image", "\"" + sqliteRS.getInt("detpicnum") + "\"")
                    .replaceAll("CATNM", "\"" + sqliteRS.getString("class") + "\"");
            System.out.println(sql);
            try {
                mysqlSt.execute(sql);
            } catch (MySQLIntegrityConstraintViolationException e) {
                System.out.print(".");
            }
            System.out.println();
        } while (sqliteRS.next());
    }
}
