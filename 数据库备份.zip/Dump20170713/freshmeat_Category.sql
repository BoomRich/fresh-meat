CREATE DATABASE  IF NOT EXISTS `freshmeat` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `freshmeat`;
-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: localhost    Database: freshmeat
-- ------------------------------------------------------
-- Server version	5.7.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Category`
--

DROP TABLE IF EXISTS `Category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `category_name_UNIQUE` (`category_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Category`
--

LOCK TABLES `Category` WRITE;
/*!40000 ALTER TABLE `Category` DISABLE KEYS */;
INSERT INTO `Category` VALUES (1,'三文鱼@海鲜水产'),(2,'东南亚风味@即烹美食'),(3,'中华美食@即烹美食'),(4,'中式主食@方便速食'),(5,'养生汤品@方便速食'),(6,'冲调饮品@饮料酒水'),(7,'冷冻点心@方便速食'),(8,'冷冻蔬菜@新鲜蔬菜'),(9,'凤梨@国产水果'),(10,'凤梨@进口水果'),(11,'半成品菜@方便速食'),(12,'原箱水果@国产水果'),(13,'原箱水果@进口水果'),(14,'原膳礼盒@礼品礼券'),(15,'叶菜类@新鲜蔬菜'),(16,'国产牛肉@精选肉类'),(17,'奇异果@进口水果'),(18,'奶酪@乳品糕点'),(19,'山竹@进口水果'),(20,'干货@粮油杂货'),(21,'日韩料理@即烹美食'),(22,'时令水果@国产水果'),(23,'易盒家宴@方便速食'),(24,'杂粮@粮油杂货'),(25,'果干/零食@粮油杂货'),(26,'果汁/饮料@饮料酒水'),(27,'柑桔橙柚@国产水果'),(28,'柑桔橙柚@进口水果'),(29,'根茎类@新鲜蔬菜'),(30,'桃@国产水果'),(31,'椰子@进口水果'),(32,'水@饮料酒水'),(33,'沙拉菜@新鲜蔬菜'),(34,'油@粮油杂货'),(35,'海产干货@海鲜水产'),(36,'火腿/培根@精选肉类'),(37,'火锅料@方便速食'),(38,'热带水果@国产水果'),(39,'热带水果@进口水果'),(40,'牛奶@乳品糕点'),(41,'牛油果@进口水果'),(42,'特色海产@海鲜水产'),(43,'猪肉@精选肉类'),(44,'瓜@国产水果'),(45,'甜点@乳品糕点'),(46,'生猛海鲜@即烹美食'),(47,'田园时蔬@即烹美食'),(48,'百香果@国产水果'),(49,'礼卡礼券@礼品礼券'),(50,'礼品礼盒@礼品礼券'),(51,'米@粮油杂货'),(52,'精致西餐@即烹美食'),(53,'经典主菜@即烹美食'),(54,'羊肉@精选肉类'),(55,'美味靓汤@即烹美食'),(56,'芒果@国产水果'),(57,'花菜/豆类@新鲜蔬菜'),(58,'苹果@国产水果'),(59,'苹果@进口水果'),(60,'茄果/瓜果类@新鲜蔬菜'),(61,'莓@国产水果'),(62,'菌菇@新鲜蔬菜'),(63,'葡萄@国产水果'),(64,'葱蒜类@新鲜蔬菜'),(65,'虾@海鲜水产'),(66,'蛋@禽类蛋品'),(67,'蛋糕@乳品糕点'),(68,'蟹@海鲜水产'),(69,'西式主食@方便速食'),(70,'调味料@粮油杂货'),(71,'豆制品@新鲜蔬菜'),(72,'贝@海鲜水产'),(73,'车厘子@进口水果'),(74,'进口牛肉@精选肉类'),(75,'酒/酒具@饮料酒水'),(76,'酸奶/乳酸饮料@乳品糕点'),(77,'面/面制品@粮油杂货'),(78,'面包@乳品糕点'),(79,'香肠@精选肉类'),(80,'香蕉@进口水果'),(81,'鱼@海鲜水产'),(82,'鸡@禽类蛋品'),(83,'鸭@禽类蛋品'),(84,'鹅/鸽/特色禽类@禽类蛋品'),(85,'黄油/奶油@乳品糕点');
/*!40000 ALTER TABLE `Category` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-07-13 18:25:45
